from setuptools import setup, find_packages

setup(
    name="NeuralPC",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        # List your project's dependencies here, e.g.,
        # 'numpy>=1.14',
    ],
    # ... possibly other options
)
